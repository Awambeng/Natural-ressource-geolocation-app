import GoogleMapReact from 'google-map-react';
import React from 'react'

const Map = ({ center, zoom }) => {
  return (
    <div style={{ height: '100vh', width: '100%' }}>
      <GoogleMapReact
        bootstrapURLKeys={{ key: 'AIzaSyCuCr59PkgN_WUCKVoxYnf9wqV1sc22lS8' }}
        defaultCenter={center}
        defaultZoom={zoom}
      >
      </GoogleMapReact>
    </div>
  );
};

export default Map