import React from 'react'
import bgImg from '../../assets/world.png';
import { useForm } from 'react-hook-form';


export default function Form() {

    const { register, handleSubmit, formState: { errors } } = useForm()
    const onSubmit = data => console.log(data);

    // console.log(watch('username'));
    
  return (
    <section>
        <div className="register">
            <div className="col-2">
                <h2>Sign In</h2>
                <span>register and enjoy our services</span>

                <form id='form' className='flex flex-col' onSubmit={handleSubmit(onSubmit)}>
                    <input type="email" {...register("email",  { required : true, maxLength: 30 })} placeholder='email' />
                    <div className='error_msg'>
                    {errors.email?.type === "required" && "email required"}
                    </div>
                    <input type="password" {...register("password",  { required : true, maxLength: 20 })} placeholder='password' />
                    <div className='error_msg'>
                    {/* {errors.username?.type === "maxLength" && "Max Length Exceed"} */}
                    {errors.password?.type === "required" && "password required"}
                    {errors.password?.type === "maxLength" && "password Max Length is 10 characters"}
                    </div>
                    <button className='btn'>Sign In</button>
                    <div>
                      <h5>Don't have an account?</h5>
                      <a href="Form.jsx" className='btn_signin'>SIGN UP</a>
                    </div>
                </form>

            </div>
            <div className="col-1">
                <img src={bgImg} alt="" />
            </div>
        </div>
    </section>
  )
}