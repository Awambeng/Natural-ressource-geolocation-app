import React from 'react'
import Logo from '../../assets/logo.png'
import './sidebar.css'
import {AiOutlineMenuFold} from 'react-icons/ai'
import {AiOutlineSearch} from 'react-icons/ai'
import {AiTwotoneHome} from 'react-icons/ai'
import {MdExplore} from 'react-icons/md'
import {GrResources} from 'react-icons/gr'
import {IoIosAddCircle} from 'react-icons/io'
import {AiFillSetting} from 'react-icons/ai'
import {BsShareFill} from 'react-icons/bs'
import {ImExit} from 'react-icons/im'
import {BsFillMoonStarsFill} from 'react-icons/bs'
import {BsFillSunFill} from 'react-icons/bs'


function Sidebar() {

  return (
    <body className="dark">
      <section className="sidebar">
        <header>
          <div className="logo-text">
            <span className="logo">
              <img src={Logo} alt="logo name" />
            </span>
              <div className="text header-text">
                <span className="name">Regena</span>
                <span className="profession">App</span>
              </div>
          </div>
          <AiOutlineMenuFold className="icon toggle" />
        </header>

        <div className="menu-bar">
          <div className="menu">
          <li className="search-box">
            <a href="#">
              <AiOutlineSearch className="icon" />
              <input type="search" placeholder='Search...'/>
            </a>
          </li>
            <ul className="menu-links">
              <li className="nav-link">
                <a href="#">
                  <AiTwotoneHome className="icon" />
                  <span className="text nav-text">Home</span>
                </a>
              </li>

              <li className="nav-link">
                <a href="#">
                  <MdExplore className="icon" />
                  <span className="text nav-text">Explore</span>
                </a>
              </li>

              <li className="nav-link">
                <a href="#">
                  <GrResources className="icon" />
                  <span className="text nav-text">Resources</span>
                </a>
              </li>

              <li className="nav-link">
                <a href="#">
                  <IoIosAddCircle className="icon" />
                  <span className="text nav-text">Add a Resource</span>
                </a>
              </li>

              <li className="nav-link">
                <a href="#">
                  <AiFillSetting className="icon" />
                  <span className="text nav-text">Setting</span>
                </a>
              </li>

              <li className="nav-link">
                <a href="#">
                  <BsShareFill className="icon" />
                  <span className="text nav-text">Share Link</span>
                </a>
              </li>
            </ul>
          </div>
          <div className="bottom-content">
            <li className="">
              <a href="#">
                <ImExit className="icon" />
                <span className="text nav-text">LogOut</span>
              </a>
            </li>

            <li className="mode">
              <div className="moon-sun">
                <BsFillMoonStarsFill className="icon moon" />
                <BsFillSunFill className="icon sun" />
              </div>
              <span className="mode-text text">Dark Mode</span>
              <div className="toggle-switch">
                <span className="switch"></span>
              </div>
            </li>
          </div>
        </div>
      </section>
    </body>
  )
}

export default Sidebar