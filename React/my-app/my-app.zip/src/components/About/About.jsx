import React from 'react'
import './about.scss'
import Walpaper from '../../assets/walpaper.jpg'
// import Video from '../../assets/Video.mp4'
import NatRes from '../../assets/types-of-natural-resources---teachoo.jpg'

function About() {
  return (
    <section className="about section" id='About'>
      <div className="secContainer">
        <div className="title">
          Our Team!!!
        </div>

        <div className="mainContent container grid">
          <div className="singleItem">
            <img src={Walpaper} alt="Image Name" />
            <h2>Kappe Priscille</h2>
            <p>
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
            </p>
          </div>

          <div className="singleItem">
            <img src={Walpaper} alt="Image Name" />
            <h2>Manfouo Patrick</h2>
            <p>
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
            </p>
          </div>

          <div className="singleItem">
            <img src={Walpaper} alt="Image Name" />
            <h2>Awambeng Rodrick</h2>
            <p>
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
              Web Developper  Web Developper  Web Developper
            </p>
          </div>
        </div>

        <div className="videoCard container">
          <div className="cardContent grid">
            <div className="cardText">
              <h2>Natural Resources.</h2>
              <p>
                Natural resources are materials from the Earth that are
                used to support life and meet people’s needs.
                Any natural substance that humans use can be considered
                a natural resource. Oil, coal, natural gas, metals, stone
                and sand are natural resources. Other natural resources
                are air, sunlight, soil and water. Animals, birds, fish and
                plants are natural resources as well. 
              </p>
            </div>

            <div className="cardVideo">
              {/* <video src={Video} autoPlay loop muted type="video/mp4"></video> */}
              <img src={NatRes} alt="Types of natural resources" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About