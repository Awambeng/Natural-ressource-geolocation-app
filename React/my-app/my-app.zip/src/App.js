// import '../src/components/Signin/sign_in.css';
// import '../src/components/signup/sign_up.css';
// import Navbar from './components/Navbar/Navbar';
// import Home from './components/Home/Home';
// import Hero from './components/Hero/Hero';
// import Resource from './components/Resource/Resource';
// import About from './components/About/About';
// import Blog from './components/Blog/Blog';
// import Footer from './components/Footer/Footer';
// import Form from './components/Signin/Form';
// import SignUp from './components/signup/SignUp';
import Sidebar from './components/Sidebar/Sidebar';
// import Map from './components/Map/Map';
import './app.css';


function App() {
  return (
    <div className="App">
      <Sidebar />
      {/* <Navbar />
      <Home /> 
      <Hero />
      <Resource />
      <About />
      <Blog />
      <Footer /> */}
      {/* <Form /> */}
      {/* <SignUp />  */}
    </div>
  );
}

export default App;
